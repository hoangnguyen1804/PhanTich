@echo off
chcp 65001 >nul
cd /d "%~dp0"
set ARENA_PHONE=1
call CHAY.bat
